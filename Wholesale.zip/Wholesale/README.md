# Account
It provides REST API for basic library activities. For the POC sake, application uses in-memory derby database and thus all the data will be lost once the application is restarted. The REST  API will be available on `http://localhost:9004/`

# Building the project
To do the build, run the command under project's root directory: `mvn clean package`

# Running the application
The default port for the application is configured as 9004 in `application.properties`.
Run the command to start the application `java -jar target/WholeSale-1-0.0.1.jar`

# Use cases thought for developing the API
  * Retrieving of all user accounts
  * Retrieving of user account transaction


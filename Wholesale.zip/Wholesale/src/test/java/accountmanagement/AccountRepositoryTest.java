package accountmanagement;

import com.wholesale.accountmanagement.model.Account;
import com.wholesale.accountmanagement.repository.AccountRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
public class AccountRepositoryTest {
	
	@Autowired
	private AccountRepository accountRepository;
	
	@Test
	public void testFindOne() {
		Optional<Account> account = accountRepository.findById(10001);
		assertThat(account.get().getAccountName() == "Account 1");
	}
	
	@Test
	public void testFindAccounts() {
		Iterable<Account> account = accountRepository.getAvailableAccounts(36632173);
		accountRepository.findById(account.get().getCustomerId());
		Optional<Account> searchAccount = accountRepository.findById(36632173);
		assertThat(searchAccount == null);
	}
}


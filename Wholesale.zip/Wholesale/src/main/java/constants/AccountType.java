package constants;

public enum AccountType {
	SAVINGS, CURRENT, LOAN, CREDITCARD
}

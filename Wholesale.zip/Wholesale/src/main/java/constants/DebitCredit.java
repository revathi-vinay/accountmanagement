package constants;

public enum DebitCredit {
	DEBIT, CREDIT
}

package constants;

public enum Currency {
	IND,
	USD
}

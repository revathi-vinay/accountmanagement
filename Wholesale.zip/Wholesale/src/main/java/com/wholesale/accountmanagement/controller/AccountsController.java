package com.wholesale.accountmanagement.controller;

import com.wholesale.accountmanagement.service.AccountsService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountsController {

    @Autowired
    private AccountsService accountsService;

    public AccountsController(AccountsService accountsService) {
        this.accountsService = accountsService;
    }

    @ApiOperation(value = "Show Available Accounts for the customer")
    @GetMapping(value = "/all/accounts/{customerId}")
    public ResponseEntity getAvailableAccounts(@PathVariable(value = "customerId") int customerId) {
        return ResponseEntity.ok(accountsService.getAvailableAccounts(customerId));
    }

    @ApiOperation(value = "Show Transactions for the selected account")
    @PostMapping(value = "/account/transactions/{accountNumber}")
    public ResponseEntity getAccountTransactions(@PathVariable(value = "accountNumber") int accountNumber) {
        return ResponseEntity.ok(accountsService.getTransactionsByAccountNumber(accountNumber));
    }
}

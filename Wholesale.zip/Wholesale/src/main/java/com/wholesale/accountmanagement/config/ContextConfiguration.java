package com.wholesale.accountmanagement.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.util.Properties;
import java.util.UUID;

@Configuration
@ComponentScan("com.wholesale")
public class ContextConfiguration {

    @Bean
    public DriverManagerDataSource dataSource() {
        Properties p = new Properties();
        p.setProperty("driverClassName", "org.apache.derby.jdbc.EmbeddedDriver");
        String url = String.format("jdbc:derby:memory:%s;create=true", UUID.randomUUID().toString());
        return new DriverManagerDataSource(url, p);
    }

    @Bean
    public DataSourceTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dataSource());
    }
}

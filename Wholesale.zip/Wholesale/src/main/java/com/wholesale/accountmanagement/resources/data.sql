create table Account (
    id INT PRIMARY KEY,
    customerId INT,
    accountNumber INT,
    accountName varchar(45),
    accountType varchar(15),
    balanceDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    currency varchar(15),
    availableBalance decimal(20,2),
    transactionDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    debitAmount decimal(20,2),
    creditAmount decimal(20,2),
    transactionType varchar(15),
    transactionDescription varchar(90)
);

insert into Account (id, customerId, accountNumber, accountName, accountType, balanceDate, currency, availableBalance, transactionDate, debitAmount, creditAmount, transactionType, transactionDescription)
                    values (1, 36632173, 123456, 'AccName', 'SAVINGS', '2019-06-04 13:50:26', 'INR', 10000,
                    '2019-06-04 13:50:26', 0, 1000, 'CREDIT', 'test transaction');

insert into Account (id, customerId, accountNumber, accountName, accountType, balanceDate, currency, availableBalance, transactionDate, debitAmount, creditAmount, transactionType, transactionDescription)
                    values (1, 36632173, 828328, 'AccName', 'LOAN', '2019-06-04 13:50:26', 'INR', 10000,
                    '2019-06-04 13:50:26', 2000, 0, 'DEBIT', 'test transaction');

insert into Account (id, customerId, accountNumber, accountName, accountType, balanceDate, currency, availableBalance, transactionDate, debitAmount, creditAmount, transactionType, transactionDescription)
                    values (1, 36632173, 99343432403204, 'AccName', 'CREDITCARD', '2019-06-04 13:50:26', 'INR', 10000,
                    '2019-06-04 13:50:26', 0, 1000, 'CREDIT', 'test transaction');

insert into Account (id, customerId, accountNumber, accountName, accountType, balanceDate, currency, availableBalance, transactionDate, debitAmount, creditAmount, transactionType, transactionDescription)
                    values (1, 36633, 483834, 'AccName', 'SAVINGS', '2019-06-04 13:50:26', 'INR', 10000,
                    '2019-06-04 13:50:26', 0, 1000, 'CREDIT', 'test transaction');


package com.wholesale.accountmanagement.service;

import com.wholesale.accountmanagement.model.Account;
import com.wholesale.accountmanagement.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

/**
 * This service takes care of business logic and acts as bridge between rest API to DAO
 */
@Service
public class AccountsService {

    @Autowired
    private AccountRepository accountRepository;

    public AccountsService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public Optional<Account> getAvailableAccounts(int customerId) {
        return accountRepository.findById(customerId);
    }

    public Iterable<Account> getTransactionsByAccountNumber(int accountNumber) {
        return accountRepository.findTransactionsByAccountNumber(accountNumber);
    }

}
